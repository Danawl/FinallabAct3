﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace myDataHelper
{
    public class myDataAccess
    {
        static string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\awild\OneDrive\Documents\Visual Studio 2013\Projects\FinAct3\FinAct3\MyDatabase.mdf;Integrated Security=True";
        SqlConnection connstr = new SqlConnection(connectionString);

        public string ValidateUser(string username, string password)
        {
            connstr.Open();

            try
            {
                using (SqlCommand cmdAdmin = new SqlCommand("AdminCheck", connstr))
                {
                    cmdAdmin.CommandType = CommandType.StoredProcedure;
                    cmdAdmin.Parameters.Add("@username", SqlDbType.NVarChar).Value = username;
                    cmdAdmin.Parameters.Add("@password", SqlDbType.NVarChar).Value = password;

                    SqlParameter resultParameter = new SqlParameter("@Result", SqlDbType.Int);
                    resultParameter.Direction = ParameterDirection.Output;
                    cmdAdmin.Parameters.Add(resultParameter);

                    cmdAdmin.ExecuteNonQuery();

                    if (resultParameter.Value != DBNull.Value)
                    {
                        string resultString = resultParameter.Value.ToString();
                        int result;
                        if (int.TryParse(resultString, out result) && result == 1)
                        {
                            return "Admin";
                        }
                    }
                }

                using (SqlCommand cmdUser = new SqlCommand("StudChecker", connstr))
                {
                    cmdUser.CommandType = CommandType.StoredProcedure;
                    cmdUser.Parameters.Add("@username", SqlDbType.NVarChar).Value = username;
                    cmdUser.Parameters.Add("@password", SqlDbType.NVarChar).Value = password;

                    SqlParameter resultParameter1 = new SqlParameter("@Result", SqlDbType.Int);
                    resultParameter1.Direction = ParameterDirection.Output;
                    cmdUser.Parameters.Add(resultParameter1);

                    cmdUser.ExecuteNonQuery();

                    if (resultParameter1.Value != DBNull.Value)
                    {
                        string resultString1 = resultParameter1.Value.ToString();
                        int result1;
                        if (int.TryParse(resultString1, out result1) && result1 == 1)
                        {
                            return "User";
                        }
                    }
                }

                return null; // or handle other cases as needed
            }
            finally
            {
                connstr.Close();
            }
        }
    }
}