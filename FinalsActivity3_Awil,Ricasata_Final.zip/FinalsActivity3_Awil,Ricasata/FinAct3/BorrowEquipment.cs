﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class BorrowEquipment : Form
    {
        myDataAccess da = new myDataAccess();
        private string username;
        private DataTable profilemail;


        public BorrowEquipment(string username, DataTable profilemail)
        {
            InitializeComponent();
            this.username = username;
            this.profilemail = profilemail;
        }

        private void BorrowEquipment_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'myDatabaseDataSet4.BorrowTable' table. You can move, or remove it, as needed.
            this.borrowTableTableAdapter.Fill(this.myDatabaseDataSet4.BorrowTable);
            // TODO: This line of code loads data into the 'myDatabaseDataSet1.EquipmentData' table. You can move, or remove it, as needed.
            this.equipmentDataTableAdapter.Fill(this.myDatabaseDataSet1.EquipmentData);
            string studentID = profilemail.Rows[0]["studentid"].ToString();
            
            dataGridView1.DataSource = da.ViewEquipmentRecord();            
            dataGridView2.DataSource = da.ViewBorrow(studentID);
            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Rows[0].Selected = true;
            }
            bind();
        }
        public void bind()
        {
            DataTable profilemail = da.LoginProfile(username);
            string studentID = profilemail.Rows[0]["studentid"].ToString();
        }
        private void btnselect_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)           
            {
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            txteqid.Text = selectedRow.Cells[0].Value.ToString();
            txteqname.Text = selectedRow.Cells[1].Value.ToString();
            btnborrow.Enabled = true;
            button1.Enabled = true;
            btnselect.Enabled = false;
            }
        }

        private void btnborrow_Click(object sender, EventArgs e)
        {
            DataTable equipmenttable = da.ViewEquipmentRecord();
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            Random uniqueid = new Random();
            int randomNumber = uniqueid.Next(10000, 99999);       
            string uniquenumber = randomNumber.ToString();
            string studentID = profilemail.Rows[0]["studentid"].ToString();
            double quantitycount = Convert.ToDouble(selectedRow.Cells[2].Value.ToString());
            string dateandtime = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
            double quantityborrowed = Convert.ToDouble(txteqquan.Text);
          
            string type = "Borrow";

            if (quantitycount >= quantityborrowed)
            {
                da.AddBorrow(uniquenumber, studentID, txteqid.Text, txteqname.Text, txteqquan.Text, dateandtime);
                da.AddNewHistory(uniquenumber, studentID, txteqid.Text, txteqname.Text, type, dateandtime, txteqquan.Text);

                double newquantity = quantitycount - quantityborrowed;

                da.BorrowQuantity(newquantity.ToString(), txteqid.Text);

                txteqid.Text = "";
                txteqname.Text = "";
                txteqquan.Text = "1";

                MessageBox.Show("Borrowed!");
                btnborrow.Enabled = false;
                button1.Enabled = false;
                btnselect.Enabled = true;
               
                dataGridView1.DataSource = da.ViewEquipmentRecord();
                dataGridView2.DataSource = da.ViewBorrow(studentID);
                if (dataGridView1.Rows.Count > 0)
                {
                    dataGridView1.Rows[0].Selected = true;
                }
            }
            else
            {
                MessageBox.Show("The amount must not be greater than the quantity");
                if (dataGridView1.Rows.Count > 0)
                {
                    dataGridView1.Rows[0].Selected = true;
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txteqid.Text = "";
            txteqname.Text = "";
            txteqquan.Text = "1";
            btnborrow.Enabled = false;
            button1.Enabled = false;
            btnselect.Enabled = true;
            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Rows[0].Selected = true;
            }
        }
    
    }
}
