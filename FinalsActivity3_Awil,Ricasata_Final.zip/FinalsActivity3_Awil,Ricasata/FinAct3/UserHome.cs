﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class UserHome : Form
    {
        myDataAccess da = new myDataAccess();
        private string username;
        private DataTable profilemail;
        public UserHome(string username, DataTable profilemail)
        {
            InitializeComponent();
            this.username = username;
            this.profilemail = profilemail;
            IsMdiContainer = true;
                    
        }

        private void UserHome_Load(object sender, EventArgs e)
        {
            
            bind();
           
        }
        public void bind()
        {
            DataTable profilemail = da.LoginProfile(username);
            string firstname = profilemail.Rows[0]["firstname"].ToString();
            string lastname = profilemail.Rows[0]["lastname"].ToString();
            label2.Text = profilemail.Rows[0]["studentid"].ToString();
            label1.Text = profilemail.Rows[0]["username"].ToString();
            label3.Text = firstname + " " + lastname;
            label4.Text = profilemail.Rows[0]["gender"].ToString();
            label5.Text = profilemail.Rows[0]["course"].ToString();

        }
        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void borrowEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BorrowEquipment bor = new BorrowEquipment(username, profilemail);
            bor.MdiParent = this;
            bor.Show();
        }

        private void returnEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReturnEquipment ret = new ReturnEquipment(username, profilemail);
            ret.MdiParent = this;
            ret.Show();
        }
    }
}
