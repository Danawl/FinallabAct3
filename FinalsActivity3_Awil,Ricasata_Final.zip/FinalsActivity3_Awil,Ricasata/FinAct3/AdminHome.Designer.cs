﻿namespace FinAct3
{
    partial class AdminHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminHome));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.systemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addingOfEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editingOfEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.passwordRecoveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addingOfUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schedulingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.returnEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.systemToolStripMenuItem,
            this.userConfigurationToolStripMenuItem,
            this.schedulingToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1045, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // systemToolStripMenuItem
            // 
            this.systemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addingOfEquipmentToolStripMenuItem,
            this.editingOfEquipmentToolStripMenuItem,
            this.viewAllRecordsToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            this.systemToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.systemToolStripMenuItem.Text = "System";
            // 
            // addingOfEquipmentToolStripMenuItem
            // 
            this.addingOfEquipmentToolStripMenuItem.Name = "addingOfEquipmentToolStripMenuItem";
            this.addingOfEquipmentToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.addingOfEquipmentToolStripMenuItem.Text = "AddingEquipment";
            this.addingOfEquipmentToolStripMenuItem.Click += new System.EventHandler(this.addingOfEquipmentToolStripMenuItem_Click);
            // 
            // editingOfEquipmentToolStripMenuItem
            // 
            this.editingOfEquipmentToolStripMenuItem.Name = "editingOfEquipmentToolStripMenuItem";
            this.editingOfEquipmentToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.editingOfEquipmentToolStripMenuItem.Text = "EditingEquipment";
            this.editingOfEquipmentToolStripMenuItem.Click += new System.EventHandler(this.editingOfEquipmentToolStripMenuItem_Click);
            // 
            // viewAllRecordsToolStripMenuItem
            // 
            this.viewAllRecordsToolStripMenuItem.Name = "viewAllRecordsToolStripMenuItem";
            this.viewAllRecordsToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.viewAllRecordsToolStripMenuItem.Text = "ViewAllRecords";
            this.viewAllRecordsToolStripMenuItem.Click += new System.EventHandler(this.viewAllRecordsToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.exitToolStripMenuItem.Text = "Logout";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // userConfigurationToolStripMenuItem
            // 
            this.userConfigurationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.passwordRecoveryToolStripMenuItem,
            this.addingOfUsersToolStripMenuItem});
            this.userConfigurationToolStripMenuItem.Name = "userConfigurationToolStripMenuItem";
            this.userConfigurationToolStripMenuItem.Size = new System.Drawing.Size(119, 20);
            this.userConfigurationToolStripMenuItem.Text = "User Configuration";
            // 
            // passwordRecoveryToolStripMenuItem
            // 
            this.passwordRecoveryToolStripMenuItem.Name = "passwordRecoveryToolStripMenuItem";
            this.passwordRecoveryToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.passwordRecoveryToolStripMenuItem.Text = "AccountRecovery";
            this.passwordRecoveryToolStripMenuItem.Click += new System.EventHandler(this.passwordRecoveryToolStripMenuItem_Click);
            // 
            // addingOfUsersToolStripMenuItem
            // 
            this.addingOfUsersToolStripMenuItem.Name = "addingOfUsersToolStripMenuItem";
            this.addingOfUsersToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.addingOfUsersToolStripMenuItem.Text = "AddingUsers";
            this.addingOfUsersToolStripMenuItem.Click += new System.EventHandler(this.addingOfUsersToolStripMenuItem_Click);
            // 
            // schedulingToolStripMenuItem
            // 
            this.schedulingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.borrowEquipmentToolStripMenuItem,
            this.returnEquipmentToolStripMenuItem});
            this.schedulingToolStripMenuItem.Name = "schedulingToolStripMenuItem";
            this.schedulingToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.schedulingToolStripMenuItem.Text = "Scheduling";
            // 
            // borrowEquipmentToolStripMenuItem
            // 
            this.borrowEquipmentToolStripMenuItem.Name = "borrowEquipmentToolStripMenuItem";
            this.borrowEquipmentToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.borrowEquipmentToolStripMenuItem.Text = "Borrow Equipment";
            this.borrowEquipmentToolStripMenuItem.Click += new System.EventHandler(this.borrowEquipmentToolStripMenuItem_Click);
            // 
            // returnEquipmentToolStripMenuItem
            // 
            this.returnEquipmentToolStripMenuItem.Name = "returnEquipmentToolStripMenuItem";
            this.returnEquipmentToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.returnEquipmentToolStripMenuItem.Text = "Return Equipment";
            this.returnEquipmentToolStripMenuItem.Click += new System.EventHandler(this.returnEquipmentToolStripMenuItem_Click);
            // 
            // AdminHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1045, 682);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "AdminHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminHome";
            this.Load += new System.EventHandler(this.AdminHome_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem systemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addingOfEquipmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editingOfEquipmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userConfigurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passwordRecoveryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addingOfUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schedulingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borrowEquipmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem returnEquipmentToolStripMenuItem;

    }
}