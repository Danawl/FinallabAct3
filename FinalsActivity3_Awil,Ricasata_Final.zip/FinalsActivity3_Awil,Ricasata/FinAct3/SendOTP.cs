﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class SendOTP : Form
    {
        private string generatedOTP;
        myDataAccess da = new myDataAccess();
        private string username;

        public SendOTP()
        {
            InitializeComponent();
        }

        private void SendOTP_Load(object sender, EventArgs e)
        {

        }

        private void butsendotp_Click(object sender, EventArgs e)
        {
            username = txtusername.Text;
            generatedOTP = da.GenerateOTP();
            string userType = da.GetUserType(username);

            if (userType == "Admin")
            {
                string adminUsername = username;
                da.StoreOTP(adminUsername, generatedOTP, userType);
                MessageBox.Show("Generated OTP: " + generatedOTP + " for Admin", "Please Save Your OTP");
            }
            else if (userType == "Student")
            {
                string studentUsername = username;
                da.StoreOTP(studentUsername, generatedOTP, userType);
                MessageBox.Show("Generated OTP: " + generatedOTP + " for Student", "Please Save Your OTP");
            }
            else
            {

                MessageBox.Show("Unknown User Type", "Error");
            }
        }

        private void butverifyotp_Click(object sender, EventArgs e)
        {
            string enteredOTP = txtverifyotp.Text;
            string username = txtusername.Text;
            string newPassword = txtnewpassword.Text;
            string confirmPassword = txtconfirmpassword.Text;


            string userType = da.GetUserType(username);
            if (enteredOTP == da.GetSavedOTP(username))
            {
               if (newPassword != confirmPassword)
            {
                MessageBox.Show("New password and confirm password do not match.", "Error");
                return;
            }

            da.ResetPassword(username, newPassword, userType);
            MessageBox.Show("Password reset successful.", "Success");
            }
            else
            {

                MessageBox.Show("Invalid Username");

            }         

            }

        }
    }


