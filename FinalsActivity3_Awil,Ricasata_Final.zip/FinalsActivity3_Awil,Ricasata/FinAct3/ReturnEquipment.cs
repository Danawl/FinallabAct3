﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class ReturnEquipment : Form
    {
        myDataAccess da = new myDataAccess();

        private string username;
        private DataTable profilemail;
        public ReturnEquipment(string username, DataTable profilemail)
        {
            InitializeComponent();
            this.username = username;
            this.profilemail = profilemail;
        }

        private void ReturnEquipment_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'myDatabaseDataSet4.BorrowTable' table. You can move, or remove it, as needed.
            this.borrowTableTableAdapter.Fill(this.myDatabaseDataSet4.BorrowTable);
            // TODO: This line of code loads data into the 'myDatabaseDataSet1.EquipmentData' table. You can move, or remove it, as needed.
            this.equipmentDataTableAdapter.Fill(this.myDatabaseDataSet1.EquipmentData);
            string studentID = profilemail.Rows[0]["studentid"].ToString();
            bind();

            dataGridView1.DataSource = da.ViewEquipmentRecord();
            dataGridView2.DataSource = da.ViewBorrow(studentID);
            if (dataGridView2.Rows.Count > 0)
            {
                dataGridView2.Rows[0].Selected = true;
            }
        }
        public void bind()
        {
            DataTable profilemail = da.LoginProfile(username);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];
                DataTable equipmenttable = da.ViewEquipmentRecord();
                Random uniqueid = new Random();
                int randomNumber = uniqueid.Next(10000, 99999);
                string uniquenumber = randomNumber.ToString();
                string studentID = profilemail.Rows[0]["studentid"].ToString();

                string dateandtime = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
                string borrowid = selectedRow.Cells[0].Value.ToString();
                string equipmentid = selectedRow.Cells[1].Value.ToString();
                string equipmentname = selectedRow.Cells[2].Value.ToString();
                string equipmentquantity = selectedRow.Cells[3].Value.ToString();
                string type = "Returned";
                int quantity = da.ReturnQuantity(equipmentid);
                da.AddReturn(uniquenumber, studentID, equipmentname, equipmentquantity, dateandtime);
                da.AddNewHistory(uniquenumber, studentID, equipmentid, equipmentname, type, dateandtime, equipmentquantity);

                double newquantity = Convert.ToDouble(quantity) + Convert.ToDouble(equipmentquantity);
                da.BorrowQuantity(newquantity.ToString(), equipmentid);


                da.ReturnRow(borrowid);
                dataGridView1.DataSource = da.ViewEquipmentRecord();
                dataGridView2.DataSource = da.ViewBorrow(studentID);
                if (dataGridView2.Rows.Count > 0)
                {
                    dataGridView2.Rows[0].Selected = true;
                }
            }
        }
    }
}