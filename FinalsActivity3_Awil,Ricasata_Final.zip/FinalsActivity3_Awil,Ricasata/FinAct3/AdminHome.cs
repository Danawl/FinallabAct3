﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class AdminHome : Form
    {
        myDataAccess da = new myDataAccess();
        public AdminHome()
        {
            InitializeComponent();
            IsMdiContainer = true;
        }

        private void addingOfUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddingUsers add = new AddingUsers();
            add.MdiParent = this;
            add.Show();
        }

        private void addingOfEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddingEquipment equip = new AddingEquipment();
            equip.MdiParent = this;
            equip.Show();
        }

        private void editingOfEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditingEquipment edit = new EditingEquipment();
            edit.MdiParent = this;
            edit.Show();
        }

        private void viewAllRecordsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewAllRecords view = new ViewAllRecords();
            view.MdiParent = this;
            view.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void passwordRecoveryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SendOTP rec = new SendOTP();
            rec.MdiParent = this;
            rec.Show();
        }

        private void borrowEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string username = "admin";            
            DataTable profilemail = da.LoginProfile(username);
            BorrowEquipment bor = new BorrowEquipment(username, profilemail);
            bor.MdiParent = this;
            bor.Show();
        }

        private void returnEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string username = "admin";          
            DataTable profilemail = da.LoginProfile(username);
            ReturnEquipment ret = new ReturnEquipment(username, profilemail);
            ret.MdiParent = this;
            ret.Show();
        }

        private void AdminHome_Load(object sender, EventArgs e)
        {

        }
    }
}
