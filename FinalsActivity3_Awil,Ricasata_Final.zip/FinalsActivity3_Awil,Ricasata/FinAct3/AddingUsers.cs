﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class AddingUsers : Form
    {
        myDataAccess da = new myDataAccess();
        public AddingUsers()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            da.AddNewUser(txtid.Text, txtfirst.Text, txtlast.Text, txtgender.Text, txtcourse.Text, txtuser.Text, txtpass.Text);
            MessageBox.Show("Data Added!");
            txtid.Text = "";
            txtfirst.Text = "";
            txtlast.Text = "";
            txtgender.Text = "";
            txtcourse.Text = "";
            txtuser.Text = "";
            txtpass.Text = "";
        }

        private void AddingUsers_Load(object sender, EventArgs e)
        {

        }
    }
}
