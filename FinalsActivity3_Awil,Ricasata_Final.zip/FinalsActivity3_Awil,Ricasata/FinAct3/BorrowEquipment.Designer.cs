﻿namespace FinAct3
{
    partial class BorrowEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BorrowEquipment));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.equipmentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDatabaseDataSet1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.myDatabaseDataSet1 = new FinAct3.MyDatabaseDataSet1();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.borrowidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrowequipmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrowedquantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borroweddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrowTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDatabaseDataSet4 = new FinAct3.MyDatabaseDataSet4();
            this.txteqname = new System.Windows.Forms.TextBox();
            this.txteqquan = new System.Windows.Forms.NumericUpDown();
            this.btnborrow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnselect = new System.Windows.Forms.Button();
            this.txteqid = new System.Windows.Forms.TextBox();
            this.ID = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.myDatabaseDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.equipmentDataTableAdapter = new FinAct3.MyDatabaseDataSet1TableAdapters.EquipmentDataTableAdapter();
            this.borrowTableTableAdapter = new FinAct3.MyDatabaseDataSet4TableAdapters.BorrowTableTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txteqquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.equipmentidDataGridViewTextBoxColumn,
            this.equipmentnameDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.equipmentDataBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(77, 28);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(580, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // equipmentidDataGridViewTextBoxColumn
            // 
            this.equipmentidDataGridViewTextBoxColumn.DataPropertyName = "equipmentid";
            this.equipmentidDataGridViewTextBoxColumn.HeaderText = "Equipment ID";
            this.equipmentidDataGridViewTextBoxColumn.Name = "equipmentidDataGridViewTextBoxColumn";
            this.equipmentidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // equipmentnameDataGridViewTextBoxColumn
            // 
            this.equipmentnameDataGridViewTextBoxColumn.DataPropertyName = "equipmentname";
            this.equipmentnameDataGridViewTextBoxColumn.HeaderText = "Equipment Name";
            this.equipmentnameDataGridViewTextBoxColumn.Name = "equipmentnameDataGridViewTextBoxColumn";
            this.equipmentnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // equipmentDataBindingSource
            // 
            this.equipmentDataBindingSource.DataMember = "EquipmentData";
            this.equipmentDataBindingSource.DataSource = this.myDatabaseDataSet1BindingSource1;
            // 
            // myDatabaseDataSet1BindingSource1
            // 
            this.myDatabaseDataSet1BindingSource1.DataSource = this.myDatabaseDataSet1;
            this.myDatabaseDataSet1BindingSource1.Position = 0;
            // 
            // myDatabaseDataSet1
            // 
            this.myDatabaseDataSet1.DataSetName = "MyDatabaseDataSet1";
            this.myDatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.borrowidDataGridViewTextBoxColumn,
            this.equipmentidDataGridViewTextBoxColumn1,
            this.borrowequipmentDataGridViewTextBoxColumn,
            this.borrowedquantityDataGridViewTextBoxColumn,
            this.borroweddateDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.borrowTableBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(77, 228);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(580, 150);
            this.dataGridView2.TabIndex = 1;
            // 
            // borrowidDataGridViewTextBoxColumn
            // 
            this.borrowidDataGridViewTextBoxColumn.DataPropertyName = "borrowid";
            this.borrowidDataGridViewTextBoxColumn.HeaderText = "Borrow ID";
            this.borrowidDataGridViewTextBoxColumn.Name = "borrowidDataGridViewTextBoxColumn";
            this.borrowidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // equipmentidDataGridViewTextBoxColumn1
            // 
            this.equipmentidDataGridViewTextBoxColumn1.DataPropertyName = "equipmentid";
            this.equipmentidDataGridViewTextBoxColumn1.HeaderText = "Equipment ID";
            this.equipmentidDataGridViewTextBoxColumn1.Name = "equipmentidDataGridViewTextBoxColumn1";
            this.equipmentidDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // borrowequipmentDataGridViewTextBoxColumn
            // 
            this.borrowequipmentDataGridViewTextBoxColumn.DataPropertyName = "borrowequipment";
            this.borrowequipmentDataGridViewTextBoxColumn.HeaderText = "Equipment Name";
            this.borrowequipmentDataGridViewTextBoxColumn.Name = "borrowequipmentDataGridViewTextBoxColumn";
            this.borrowequipmentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borrowedquantityDataGridViewTextBoxColumn
            // 
            this.borrowedquantityDataGridViewTextBoxColumn.DataPropertyName = "borrowedquantity";
            this.borrowedquantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.borrowedquantityDataGridViewTextBoxColumn.Name = "borrowedquantityDataGridViewTextBoxColumn";
            this.borrowedquantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borroweddateDataGridViewTextBoxColumn
            // 
            this.borroweddateDataGridViewTextBoxColumn.DataPropertyName = "borroweddate";
            this.borroweddateDataGridViewTextBoxColumn.HeaderText = "Date & Time";
            this.borroweddateDataGridViewTextBoxColumn.Name = "borroweddateDataGridViewTextBoxColumn";
            this.borroweddateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borrowTableBindingSource
            // 
            this.borrowTableBindingSource.DataMember = "BorrowTable";
            this.borrowTableBindingSource.DataSource = this.myDatabaseDataSet4;
            // 
            // myDatabaseDataSet4
            // 
            this.myDatabaseDataSet4.DataSetName = "MyDatabaseDataSet4";
            this.myDatabaseDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txteqname
            // 
            this.txteqname.Location = new System.Drawing.Point(339, 441);
            this.txteqname.Name = "txteqname";
            this.txteqname.ReadOnly = true;
            this.txteqname.Size = new System.Drawing.Size(100, 20);
            this.txteqname.TabIndex = 2;
            // 
            // txteqquan
            // 
            this.txteqquan.Location = new System.Drawing.Point(536, 441);
            this.txteqquan.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.txteqquan.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txteqquan.Name = "txteqquan";
            this.txteqquan.Size = new System.Drawing.Size(120, 20);
            this.txteqquan.TabIndex = 3;
            this.txteqquan.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnborrow
            // 
            this.btnborrow.Enabled = false;
            this.btnborrow.Location = new System.Drawing.Point(339, 394);
            this.btnborrow.Name = "btnborrow";
            this.btnborrow.Size = new System.Drawing.Size(75, 23);
            this.btnborrow.TabIndex = 4;
            this.btnborrow.Text = "Borrow";
            this.btnborrow.UseVisualStyleBackColor = true;
            this.btnborrow.Click += new System.EventHandler(this.btnborrow_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(232, 444);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Equipment Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(472, 444);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Quantity";
            // 
            // btnselect
            // 
            this.btnselect.Location = new System.Drawing.Point(77, 394);
            this.btnselect.Name = "btnselect";
            this.btnselect.Size = new System.Drawing.Size(75, 23);
            this.btnselect.TabIndex = 7;
            this.btnselect.Text = "Select";
            this.btnselect.UseVisualStyleBackColor = true;
            this.btnselect.Click += new System.EventHandler(this.btnselect_Click);
            // 
            // txteqid
            // 
            this.txteqid.Location = new System.Drawing.Point(102, 441);
            this.txteqid.Name = "txteqid";
            this.txteqid.ReadOnly = true;
            this.txteqid.Size = new System.Drawing.Size(100, 20);
            this.txteqid.TabIndex = 8;
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Location = new System.Drawing.Point(74, 444);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(18, 13);
            this.ID.TabIndex = 9;
            this.ID.Text = "ID";
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(582, 394);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // myDatabaseDataSet1BindingSource
            // 
            this.myDatabaseDataSet1BindingSource.DataSource = this.myDatabaseDataSet1;
            this.myDatabaseDataSet1BindingSource.Position = 0;
            // 
            // equipmentDataTableAdapter
            // 
            this.equipmentDataTableAdapter.ClearBeforeFill = true;
            // 
            // borrowTableTableAdapter
            // 
            this.borrowTableTableAdapter.ClearBeforeFill = true;
            // 
            // BorrowEquipment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(742, 515);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.txteqid);
            this.Controls.Add(this.btnselect);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnborrow);
            this.Controls.Add(this.txteqquan);
            this.Controls.Add(this.txteqname);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BorrowEquipment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BorrowEquipment";
            this.Load += new System.EventHandler(this.BorrowEquipment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txteqquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox txteqname;
        private System.Windows.Forms.NumericUpDown txteqquan;
        private System.Windows.Forms.Button btnborrow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnselect;
        private System.Windows.Forms.TextBox txteqid;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource myDatabaseDataSet1BindingSource1;
        private MyDatabaseDataSet1 myDatabaseDataSet1;
        private System.Windows.Forms.BindingSource myDatabaseDataSet1BindingSource;
        private System.Windows.Forms.BindingSource equipmentDataBindingSource;
        private MyDatabaseDataSet1TableAdapters.EquipmentDataTableAdapter equipmentDataTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private MyDatabaseDataSet4 myDatabaseDataSet4;
        private System.Windows.Forms.BindingSource borrowTableBindingSource;
        private MyDatabaseDataSet4TableAdapters.BorrowTableTableAdapter borrowTableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrowidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrowequipmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrowedquantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn borroweddateDataGridViewTextBoxColumn;
    }
}