﻿namespace FinAct3
{
    partial class ReturnEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReturnEquipment));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.equipmentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDatabaseDataSet1 = new FinAct3.MyDatabaseDataSet1();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.borrowidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrowequipmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrowedquantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borroweddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrowTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDatabaseDataSet4 = new FinAct3.MyDatabaseDataSet4();
            this.button1 = new System.Windows.Forms.Button();
            this.myDatabaseDataSet = new FinAct3.MyDatabaseDataSet();
            this.myDatabaseDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.equipmentDataTableAdapter = new FinAct3.MyDatabaseDataSet1TableAdapters.EquipmentDataTableAdapter();
            this.borrowTableTableAdapter = new FinAct3.MyDatabaseDataSet4TableAdapters.BorrowTableTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.equipmentidDataGridViewTextBoxColumn,
            this.equipmentnameDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.equipmentDataBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(39, 46);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(613, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // equipmentidDataGridViewTextBoxColumn
            // 
            this.equipmentidDataGridViewTextBoxColumn.DataPropertyName = "equipmentid";
            this.equipmentidDataGridViewTextBoxColumn.HeaderText = "Equipment ID";
            this.equipmentidDataGridViewTextBoxColumn.Name = "equipmentidDataGridViewTextBoxColumn";
            this.equipmentidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // equipmentnameDataGridViewTextBoxColumn
            // 
            this.equipmentnameDataGridViewTextBoxColumn.DataPropertyName = "equipmentname";
            this.equipmentnameDataGridViewTextBoxColumn.HeaderText = "Equipment Name";
            this.equipmentnameDataGridViewTextBoxColumn.Name = "equipmentnameDataGridViewTextBoxColumn";
            this.equipmentnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // equipmentDataBindingSource
            // 
            this.equipmentDataBindingSource.DataMember = "EquipmentData";
            this.equipmentDataBindingSource.DataSource = this.myDatabaseDataSet1;
            // 
            // myDatabaseDataSet1
            // 
            this.myDatabaseDataSet1.DataSetName = "MyDatabaseDataSet1";
            this.myDatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.borrowidDataGridViewTextBoxColumn,
            this.equipmentidDataGridViewTextBoxColumn1,
            this.borrowequipmentDataGridViewTextBoxColumn,
            this.borrowedquantityDataGridViewTextBoxColumn,
            this.borroweddateDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.borrowTableBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(39, 221);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(613, 150);
            this.dataGridView2.TabIndex = 1;
            // 
            // borrowidDataGridViewTextBoxColumn
            // 
            this.borrowidDataGridViewTextBoxColumn.DataPropertyName = "borrowid";
            this.borrowidDataGridViewTextBoxColumn.HeaderText = "Borrow ID";
            this.borrowidDataGridViewTextBoxColumn.Name = "borrowidDataGridViewTextBoxColumn";
            this.borrowidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // equipmentidDataGridViewTextBoxColumn1
            // 
            this.equipmentidDataGridViewTextBoxColumn1.DataPropertyName = "equipmentid";
            this.equipmentidDataGridViewTextBoxColumn1.HeaderText = "Equipment ID";
            this.equipmentidDataGridViewTextBoxColumn1.Name = "equipmentidDataGridViewTextBoxColumn1";
            this.equipmentidDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // borrowequipmentDataGridViewTextBoxColumn
            // 
            this.borrowequipmentDataGridViewTextBoxColumn.DataPropertyName = "borrowequipment";
            this.borrowequipmentDataGridViewTextBoxColumn.HeaderText = "Equipment Name";
            this.borrowequipmentDataGridViewTextBoxColumn.Name = "borrowequipmentDataGridViewTextBoxColumn";
            this.borrowequipmentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borrowedquantityDataGridViewTextBoxColumn
            // 
            this.borrowedquantityDataGridViewTextBoxColumn.DataPropertyName = "borrowedquantity";
            this.borrowedquantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.borrowedquantityDataGridViewTextBoxColumn.Name = "borrowedquantityDataGridViewTextBoxColumn";
            this.borrowedquantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borroweddateDataGridViewTextBoxColumn
            // 
            this.borroweddateDataGridViewTextBoxColumn.DataPropertyName = "borroweddate";
            this.borroweddateDataGridViewTextBoxColumn.HeaderText = "Date & Time";
            this.borroweddateDataGridViewTextBoxColumn.Name = "borroweddateDataGridViewTextBoxColumn";
            this.borroweddateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borrowTableBindingSource
            // 
            this.borrowTableBindingSource.DataMember = "BorrowTable";
            this.borrowTableBindingSource.DataSource = this.myDatabaseDataSet4;
            // 
            // myDatabaseDataSet4
            // 
            this.myDatabaseDataSet4.DataSetName = "MyDatabaseDataSet4";
            this.myDatabaseDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(305, 392);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 26);
            this.button1.TabIndex = 2;
            this.button1.Text = "Return";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // myDatabaseDataSet
            // 
            this.myDatabaseDataSet.DataSetName = "MyDatabaseDataSet";
            this.myDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // myDatabaseDataSetBindingSource
            // 
            this.myDatabaseDataSetBindingSource.DataSource = this.myDatabaseDataSet;
            this.myDatabaseDataSetBindingSource.Position = 0;
            // 
            // equipmentDataTableAdapter
            // 
            this.equipmentDataTableAdapter.ClearBeforeFill = true;
            // 
            // borrowTableTableAdapter
            // 
            this.borrowTableTableAdapter.ClearBeforeFill = true;
            // 
            // ReturnEquipment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(694, 436);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReturnEquipment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReturnEquipment";
            this.Load += new System.EventHandler(this.ReturnEquipment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource myDatabaseDataSetBindingSource;
        private MyDatabaseDataSet myDatabaseDataSet;
        private MyDatabaseDataSet1 myDatabaseDataSet1;
        private System.Windows.Forms.BindingSource equipmentDataBindingSource;
        private MyDatabaseDataSet1TableAdapters.EquipmentDataTableAdapter equipmentDataTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private MyDatabaseDataSet4 myDatabaseDataSet4;
        private System.Windows.Forms.BindingSource borrowTableBindingSource;
        private MyDatabaseDataSet4TableAdapters.BorrowTableTableAdapter borrowTableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrowidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrowequipmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrowedquantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn borroweddateDataGridViewTextBoxColumn;
    }
}