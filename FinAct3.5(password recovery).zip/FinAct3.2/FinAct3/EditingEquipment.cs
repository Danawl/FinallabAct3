﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class EditingEquipment : Form
    {
        myDataAccess da = new myDataAccess();
        public EditingEquipment()
        {
            InitializeComponent();
        }

        private void EditingEquipment_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = da.ViewEquipmentRecord();
            dataGridView1.Rows[0].Selected = true;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            txteqid.Text = selectedRow.Cells[0].Value.ToString();
            txteqname.Text = selectedRow.Cells[1].Value.ToString();
            txteqquan.Text = selectedRow.Cells[2].Value.ToString();
            txteqdesc.Text = selectedRow.Cells[3].Value.ToString();
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            da.EditEquipmentRecord(txteqid.Text, txteqname.Text, txteqquan.Text, txteqdesc.Text);
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;

            txteqid.Text = "";
            txteqname.Text = "";
            txteqquan.Text = "";
            txteqdesc.Text = "";
            MessageBox.Show("Data Updated!");
            dataGridView1.Rows[0].Selected = true;
            dataGridView1.DataSource = da.ViewEquipmentRecord();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            da.DeleteEquipmentRow(txteqid.Text);
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            txteqid.Text = "";
            txteqname.Text = "";
            txteqquan.Text = "";
            txteqdesc.Text = "";
            MessageBox.Show("Data Deleted!");
            dataGridView1.Rows[0].Selected = true;
            dataGridView1.DataSource = da.ViewEquipmentRecord();
        }
    }
}
