﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class AccountRecovery : Form
    {
        public AccountRecovery()
        {
            InitializeComponent();
        }
        myDataAccess mda = new myDataAccess();
        private void butreset_Click(object sender, EventArgs e)
        {


            string username = txtUsername.Text;
            string newPassword = txtnewpassword.Text;
            string confirmPassword = txtconfirmpassword.Text;

            // Retrieve the user type based on the username
            string userType = mda.GetUserType(username);

            // Check if new password and confirm password match
            if (newPassword != confirmPassword)
            {
                MessageBox.Show("New password and confirm password do not match.", "Error");
                return;
            }

            // Reset the password in the database
            mda.ResetPassword(username, newPassword, userType);
            MessageBox.Show("Password reset successful.", "Success");

  
        }
         
    }
}