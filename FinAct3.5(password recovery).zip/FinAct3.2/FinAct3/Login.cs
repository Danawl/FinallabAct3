﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        myDataAccess da = new myDataAccess();
        private void butlog_Click(object sender, EventArgs e)
        {
            string username = txtusername.Text;
            string password = txtpassword.Text;

            string userType = da.ValidateUser(username, password);

            if (userType == "User")
            {
              
                
                MessageBox.Show("User login successful");
                UserHome UserHome = new UserHome();
                UserHome.Show();
                Close();
            }
            else if (userType == "Admin")
            {
                
                MessageBox.Show("Admin login successful");
                AdminHome AdminHome = new AdminHome();
                AdminHome.Show();
                Close();
            }
            else
            {
                
                MessageBox.Show("Invalid username or password");
               
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void Forgot_Click(object sender, EventArgs e)
        {
            SendOTP so = new SendOTP();
            this.Hide();
            so.Show();
        }
    }
}
