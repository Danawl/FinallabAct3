﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace myDataHelper
{
    public class myDataAccess
    {
        static string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\awild\OneDrive\Documents\Visual Studio 2013\Projects\FinAct3.2(Borrow and Return nalang kulang 70% done)\FinAct3.2\FinAct3\MyDatabase.mdf;Integrated Security=True";
        SqlConnection connstr = new SqlConnection(connectionString);
        #region ValidateAdmin&User
        public string ValidateUser(string username, string password)
        {
            connstr.Open();

            try
            {
                using (SqlCommand cmdAdmin = new SqlCommand("AdminCheck", connstr))
                {
                    cmdAdmin.CommandType = CommandType.StoredProcedure;
                    cmdAdmin.Parameters.Add("@username", SqlDbType.NVarChar).Value = username;
                    cmdAdmin.Parameters.Add("@password", SqlDbType.NVarChar).Value = password;

                    SqlParameter resultParameter = new SqlParameter("@Result", SqlDbType.Int);
                    resultParameter.Direction = ParameterDirection.Output;
                    cmdAdmin.Parameters.Add(resultParameter);

                    cmdAdmin.ExecuteNonQuery();

                    if (resultParameter.Value != DBNull.Value)
                    {
                        string resultString = resultParameter.Value.ToString();
                        int result;
                        if (int.TryParse(resultString, out result) && result == 1)
                        {
                            return "Admin";
                        }
                    }
                }

                using (SqlCommand cmdUser = new SqlCommand("StudChecker", connstr))
                {
                    cmdUser.CommandType = CommandType.StoredProcedure;
                    cmdUser.Parameters.Add("@username", SqlDbType.NVarChar).Value = username;
                    cmdUser.Parameters.Add("@password", SqlDbType.NVarChar).Value = password;

                    SqlParameter resultParameter1 = new SqlParameter("@Result", SqlDbType.Int);
                    resultParameter1.Direction = ParameterDirection.Output;
                    cmdUser.Parameters.Add(resultParameter1);

                    cmdUser.ExecuteNonQuery();

                    if (resultParameter1.Value != DBNull.Value)
                    {
                        string resultString1 = resultParameter1.Value.ToString();
                        int result1;
                        if (int.TryParse(resultString1, out result1) && result1 == 1)
                        {
                            return "User";
                        }
                    }
                }

                return null; 
            }
            finally
            {
                connstr.Close();
            }
        }
        #endregion

        #region AddUser
        public void AddNewUser(string studentid, string firstname, string lastname, string gender, string course, string username, string password)
        {
            connstr.Open();
            SqlCommand saveCMD = new SqlCommand("AddNewUser", connstr);
            saveCMD.CommandType = CommandType.StoredProcedure;
            saveCMD.Parameters.Add("studentid", SqlDbType.NVarChar).Value = studentid;
            saveCMD.Parameters.Add("firstname", SqlDbType.NVarChar).Value = firstname;
            saveCMD.Parameters.Add("lastname", SqlDbType.NVarChar).Value = lastname;
            saveCMD.Parameters.Add("gender", SqlDbType.NVarChar).Value = gender;
            saveCMD.Parameters.Add("course", SqlDbType.NVarChar).Value = course;
            saveCMD.Parameters.Add("username", SqlDbType.NVarChar).Value = username;
            saveCMD.Parameters.Add("password", SqlDbType.NVarChar).Value = password;
            saveCMD.ExecuteNonQuery();
            connstr.Close();
        }
        #endregion

        #region AddEquipment
        public void AddNewEquipment(string equipmentid,string equipmentname, string quantity, string description)
        {
            connstr.Open();
            SqlCommand saveCMD = new SqlCommand("AddNewEquipment", connstr);
            saveCMD.CommandType = CommandType.StoredProcedure;
            saveCMD.Parameters.Add("equipmentid", SqlDbType.NVarChar).Value = equipmentid;
            saveCMD.Parameters.Add("equipmentname", SqlDbType.NVarChar).Value = equipmentname;
            saveCMD.Parameters.Add("quantity", SqlDbType.NVarChar).Value = quantity;
            saveCMD.Parameters.Add("description", SqlDbType.NVarChar).Value = description;
            saveCMD.ExecuteNonQuery();
            connstr.Close();
        }
        #endregion

        #region ViewEquip
        public DataTable ViewEquipmentRecord()
        {
            DataTable dt = new DataTable();
            using (SqlCommand display = new SqlCommand("ViewEquipmentRecord", connstr))
            {
                display.CommandType = CommandType.StoredProcedure;
                connstr.Open();
                using (SqlDataAdapter da = new SqlDataAdapter(display))
                {
                    da.Fill(dt);
                }
                connstr.Close();
            }

            return dt;
        }
        #endregion

        #region EditEquip
        public void EditEquipmentRecord(string equipmentid, string equipmentname, string quantity, string description)
        {
            connstr.Open();
            SqlCommand saveCMD = new SqlCommand("EditEquipmentRecord", connstr);
            saveCMD.CommandType = CommandType.StoredProcedure;
            saveCMD.Parameters.Add("equipmentid", SqlDbType.NVarChar).Value = equipmentid;
            saveCMD.Parameters.Add("equipmentname", SqlDbType.NVarChar).Value = equipmentname;
            saveCMD.Parameters.Add("quantity", SqlDbType.NVarChar).Value = quantity;
            saveCMD.Parameters.Add("description", SqlDbType.NVarChar).Value = description;
            saveCMD.ExecuteNonQuery();
            connstr.Close();
        }
        #endregion

        #region DeleteEquipment
        public void DeleteEquipmentRow(string equipmentid)
        {
            connstr.Open();
            SqlCommand saveCMD = new SqlCommand("DeleteEquipmentRow", connstr);
            saveCMD.CommandType = CommandType.StoredProcedure;
            saveCMD.Parameters.Add("equipmentid", SqlDbType.NVarChar).Value = equipmentid;
            saveCMD.ExecuteNonQuery();
            connstr.Close();
        }
        #endregion

        #region StudentRecord
        public DataTable ViewStudentRecord()
        {
            DataTable dt = new DataTable();
            using (SqlCommand display = new SqlCommand("ViewStudentRecord", connstr))
            {
                display.CommandType = CommandType.StoredProcedure;
                connstr.Open();
                using (SqlDataAdapter da = new SqlDataAdapter(display))
                {
                    da.Fill(dt);
                }
                connstr.Close();
            }

            return dt;
        }
#endregion

        #region Login 
        public DataTable LoginProfile(string studentid)
        {
            DataTable dt = new DataTable();
            using (SqlCommand display = new SqlCommand("LoginProfile", connstr))
            {
                display.CommandType = CommandType.StoredProcedure;
                connstr.Open();
                display.Parameters.Add("studentid", SqlDbType.NVarChar).Value = studentid;

                using (SqlDataAdapter da = new SqlDataAdapter(display))
                {
                    da.Fill(dt);
                }

                connstr.Close();
            }

            return dt;
        }
       #endregion

        #region SendOTP
        public string GetUserType(string username)
        {
            connstr.Open();
            try
            {
                using (SqlCommand cmd = new SqlCommand("GetUserType", connstr))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = username;

                    SqlParameter userTypeParameter = new SqlParameter("@UserType", SqlDbType.NVarChar, 50);
                    userTypeParameter.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(userTypeParameter);

                    cmd.ExecuteNonQuery();

                 
                    return userTypeParameter.Value.ToString();
                }
            }
            finally
            {
                connstr.Close();
            }
        }
        public string GenerateOTP()
        {
            Random random = new Random();
            int otp = random.Next(100000, 999999);
            return otp.ToString();
        }

        public void StoreOTP(string username, string otp,string userType)
        {
            connstr.Open();

            using (SqlCommand command = new SqlCommand("StoreUserOTP", connstr))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@GeneratedOTP", otp);
                command.Parameters.AddWithValue("@UserType", userType);

                command.ExecuteNonQuery();
            }
        connstr.Close();
    }

        public string GetSavedOTP(string username)
        {
            string savedOTP = null;

            try
            {
                connstr.Open();

                using (SqlCommand command = new SqlCommand("GetSavedOTP", connstr))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Username", username);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                       
                            savedOTP = reader["generatedOTP"].ToString();
                        }
                    }
                }
            }
            finally
            {
                connstr.Close();
            }

            return savedOTP;
        }
        public bool IsOTPValid(string username)
        {
            try
            {
                connstr.Open();

                using (SqlCommand cmd = new SqlCommand("IsOTPValid", connstr))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Username", username);

                   
                    object result = cmd.ExecuteScalar();

                
                    return result != null && result.ToString() == "1";
                }
            }
            finally
            {   
                connstr.Close();
            }
        }


        #endregion

        #region RecoverPass
        public void ResetPassword(string username, string newPassword, string userType)
        {
            connstr.Open();

            using (SqlCommand command = new SqlCommand("ResetPassword", connstr))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@NewPassword", newPassword);
                command.Parameters.AddWithValue("@UserType", userType);

                command.ExecuteNonQuery();
            }


            connstr.Close();

        }
        #endregion
    }
}

        