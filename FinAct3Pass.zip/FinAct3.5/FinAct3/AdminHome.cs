﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinAct3
{
    public partial class AdminHome : Form
    {
        public AdminHome()
        {
            InitializeComponent();
        }

        private void addingOfUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddingUsers add = new AddingUsers();
            add.Show();
        }

        private void addingOfEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddingEquipment equip = new AddingEquipment();
            equip.Show();
        }

        private void editingOfEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditingEquipment edit = new EditingEquipment();
            edit.Show();
        }

        private void viewAllRecordsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewAllRecords view = new ViewAllRecords();
            view.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void passwordRecoveryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AccountRecovery rec = new AccountRecovery();
            rec.Show();
        }
    }
}
