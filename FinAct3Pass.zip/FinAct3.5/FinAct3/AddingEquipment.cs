﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;


namespace FinAct3
{
    public partial class AddingEquipment : Form
    {
        myDataAccess da = new myDataAccess();
        public AddingEquipment()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Random uniqueid = new Random();
            int randomNumber = uniqueid.Next(10000, 100000); 

            
            string uniqueequipment = randomNumber.ToString();
            da.AddNewEquipment(uniqueequipment, txteqname.Text, txteqquan.Text, txteqdesc.Text);
            txteqname.Text="";
            txteqquan.Text="";
            txteqdesc.Text = "";
            MessageBox.Show("Data Added!");
            dataGridView1.DataSource = da.ViewEquipmentRecord();
        }

        private void AddingEquipment_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = da.ViewEquipmentRecord();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.DataSource = da.ViewEquipmentRecord();
        }
    }
}
