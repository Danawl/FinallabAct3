﻿namespace FinAct3
{
    partial class AdminHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.systemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addingOfEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editingOfEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.passwordRecoveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addingOfUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.systemToolStripMenuItem,
            this.userConfigurationToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1034, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // systemToolStripMenuItem
            // 
            this.systemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addingOfEquipmentToolStripMenuItem,
            this.editingOfEquipmentToolStripMenuItem,
            this.viewAllRecordsToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            this.systemToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.systemToolStripMenuItem.Text = "System";
            // 
            // addingOfEquipmentToolStripMenuItem
            // 
            this.addingOfEquipmentToolStripMenuItem.Name = "addingOfEquipmentToolStripMenuItem";
            this.addingOfEquipmentToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.addingOfEquipmentToolStripMenuItem.Text = "AddingEquipment";
            this.addingOfEquipmentToolStripMenuItem.Click += new System.EventHandler(this.addingOfEquipmentToolStripMenuItem_Click);
            // 
            // editingOfEquipmentToolStripMenuItem
            // 
            this.editingOfEquipmentToolStripMenuItem.Name = "editingOfEquipmentToolStripMenuItem";
            this.editingOfEquipmentToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.editingOfEquipmentToolStripMenuItem.Text = "EditingEquipment";
            this.editingOfEquipmentToolStripMenuItem.Click += new System.EventHandler(this.editingOfEquipmentToolStripMenuItem_Click);
            // 
            // viewAllRecordsToolStripMenuItem
            // 
            this.viewAllRecordsToolStripMenuItem.Name = "viewAllRecordsToolStripMenuItem";
            this.viewAllRecordsToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.viewAllRecordsToolStripMenuItem.Text = "ViewAllRecords";
            this.viewAllRecordsToolStripMenuItem.Click += new System.EventHandler(this.viewAllRecordsToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.exitToolStripMenuItem.Text = "Logout";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // userConfigurationToolStripMenuItem
            // 
            this.userConfigurationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.passwordRecoveryToolStripMenuItem,
            this.addingOfUsersToolStripMenuItem});
            this.userConfigurationToolStripMenuItem.Name = "userConfigurationToolStripMenuItem";
            this.userConfigurationToolStripMenuItem.Size = new System.Drawing.Size(119, 20);
            this.userConfigurationToolStripMenuItem.Text = "User Configuration";
            // 
            // passwordRecoveryToolStripMenuItem
            // 
            this.passwordRecoveryToolStripMenuItem.Name = "passwordRecoveryToolStripMenuItem";
            this.passwordRecoveryToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.passwordRecoveryToolStripMenuItem.Text = "AccountRecovery";
            this.passwordRecoveryToolStripMenuItem.Click += new System.EventHandler(this.passwordRecoveryToolStripMenuItem_Click);
            // 
            // addingOfUsersToolStripMenuItem
            // 
            this.addingOfUsersToolStripMenuItem.Name = "addingOfUsersToolStripMenuItem";
            this.addingOfUsersToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.addingOfUsersToolStripMenuItem.Text = "AddingUsers";
            this.addingOfUsersToolStripMenuItem.Click += new System.EventHandler(this.addingOfUsersToolStripMenuItem_Click);
            // 
            // AdminHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1034, 561);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "AdminHome";
            this.Text = "AdminHome";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem systemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addingOfEquipmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editingOfEquipmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userConfigurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passwordRecoveryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addingOfUsersToolStripMenuItem;

    }
}