﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class ViewAllRecords : Form
    {
        myDataAccess da = new myDataAccess();
        public ViewAllRecords()
        {
            InitializeComponent();
        }

        private void ViewAllRecords_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = da.ViewEquipmentRecord();
            dataGridView2.DataSource = da.ViewStudentRecord();
        }
    }
}
