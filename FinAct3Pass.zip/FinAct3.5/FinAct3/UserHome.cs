﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;

namespace FinAct3
{
    public partial class UserHome : Form
    {
        myDataAccess da = new myDataAccess();
     
        public UserHome()
        {
            InitializeComponent();
        }

        private void UserHome_Load(object sender, EventArgs e)
        {
            
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void borrowEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BorrowEquipment bor = new BorrowEquipment();
            bor.Show();
        }

        private void returnEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReturnEquipment ret = new ReturnEquipment();
            ret.Show();
        }
    }
}
