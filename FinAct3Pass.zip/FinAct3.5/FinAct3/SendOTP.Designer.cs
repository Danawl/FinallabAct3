﻿namespace FinAct3
{
    partial class SendOTP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtverifyotp = new System.Windows.Forms.TextBox();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.butsendotp = new System.Windows.Forms.Button();
            this.butverifyotp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter Verification Code";
            // 
            // txtverifyotp
            // 
            this.txtverifyotp.Location = new System.Drawing.Point(156, 98);
            this.txtverifyotp.Name = "txtverifyotp";
            this.txtverifyotp.Size = new System.Drawing.Size(155, 20);
            this.txtverifyotp.TabIndex = 2;
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(156, 38);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(155, 20);
            this.txtusername.TabIndex = 3;
            // 
            // butsendotp
            // 
            this.butsendotp.Location = new System.Drawing.Point(339, 37);
            this.butsendotp.Name = "butsendotp";
            this.butsendotp.Size = new System.Drawing.Size(75, 23);
            this.butsendotp.TabIndex = 4;
            this.butsendotp.Text = "Send OTP";
            this.butsendotp.UseVisualStyleBackColor = true;
            this.butsendotp.Click += new System.EventHandler(this.butsendotp_Click);
            // 
            // butverifyotp
            // 
            this.butverifyotp.Location = new System.Drawing.Point(338, 97);
            this.butverifyotp.Name = "butverifyotp";
            this.butverifyotp.Size = new System.Drawing.Size(75, 23);
            this.butverifyotp.TabIndex = 5;
            this.butverifyotp.Text = "Verify OTP";
            this.butverifyotp.UseVisualStyleBackColor = true;
            this.butverifyotp.Click += new System.EventHandler(this.butverifyotp_Click);
            // 
            // SendOTP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(434, 169);
            this.Controls.Add(this.butverifyotp);
            this.Controls.Add(this.butsendotp);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.txtverifyotp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SendOTP";
            this.Text = "SendOTP";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtverifyotp;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Button butsendotp;
        private System.Windows.Forms.Button butverifyotp;
    }
}