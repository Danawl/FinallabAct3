﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myDataHelper;
namespace FinAct3
{
    public partial class SendOTP : Form
    {
          private string generatedOTP;
        myDataAccess da = new myDataAccess();
        private string username;
        

        public SendOTP()
        {
            InitializeComponent();
        }

        private void butsendotp_Click(object sender, EventArgs e)
        {
            username = txtusername.Text;
            generatedOTP = da.GenerateOTP();
            string userType = da.GetUserType(username);

            if (userType == "Admin")
            {
                string adminUsername = username;
                da.StoreOTP(adminUsername, generatedOTP,userType);
                MessageBox.Show("Generated OTP: " + generatedOTP + " for Admin", "Please Save Your OTP");
            }
            else if (userType == "Student")
            {
                string studentUsername = username;
                da.StoreOTP(studentUsername, generatedOTP, userType);
                MessageBox.Show("Generated OTP: " + generatedOTP + " for Student", "Please Save Your OTP");
            }
            else
            {

                MessageBox.Show("Unknown User Type", "Error");
            }
        }
 

        private void butverifyotp_Click(object sender, EventArgs e)
        {
            string enteredOTP = txtverifyotp.Text;

            if (enteredOTP == da.GetSavedOTP(username))
            {
                MessageBox.Show("OTP Verified Successfully", "Success");
                AccountRecovery ar = new AccountRecovery();
                ar.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid OTP. Please try again.", "Error");
             
            }
        }
    }
}